﻿---
tags:
  - "luggage scale"
  - "travel tips"
  - "airline baggage limits"
categories:
  - "Guides"
title: "Hello World"
date: 2025-09-30
draft: false
---

tags:
  - "luggage scale"
  - "travel tips"
  - "airline baggage limits"
categories:
  - "Guides"
This is the first test post on the **Luggage Scale Blog**.  
If you can read this, Hugo + PaperMod is working correctly!

